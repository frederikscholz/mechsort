#include <ros/ros.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <angles_msg/poseAngles.h>
#include <cmath>
#include <moveit/robot_state/robot_state.h>
#include <iostream>

using namespace std;

double pi = acos(-1);

bool poseCallback(angles_msg::poseAngles::Request  &req,
                  angles_msg::poseAngles::Response &res)

{ 
  
  ROS_INFO("robot will go to the specific pose angles");
  //res.result = "successfully";

    static const std::string PLANNING_GROUP = "sia10f_manipulator";
    moveit::planning_interface::MoveGroupInterface move_group(PLANNING_GROUP);
    const robot_state::JointModelGroup* joint_model_group = move_group.getCurrentState()->getJointModelGroup(PLANNING_GROUP);
    move_group.setPoseReferenceFrame("base_link");
    move_group.setGoalJointTolerance(0.01);
    move_group.setMaxAccelerationScalingFactor(0.2);
    move_group.setMaxVelocityScalingFactor(0.2);

    std::vector<double> angles_rad;
    for (double angle_deg : req.angles) {
        angles_rad.push_back(angle_deg * pi / 180.0);
    }
    //std::vector<double> pose1 = {105*pi/180,90*pi/180,-90*pi/180,76*pi/180,-90*pi/180,90*pi/180,3*pi/180};
    move_group.setJointValueTarget(angles_rad);
    move_group.move();
    //sleep(1);
      
  return 0;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "mechsort_server");
  ros::NodeHandle n;

//ros::ServiceServer service = n.advertiseService<pose_msg::poseAngles::Request, pose_msg::poseAngles::Response>("pose", poseCallback);

  ros::ServiceServer service = n.advertiseService("poseAngles", poseCallback);
  //cout << "Ready to receive the pose'number" << endl;
  ROS_INFO("Ready to receive the pose angles");
//   ros::AsyncSpinner spinner(5);
//   spinner.start();
//   ros::waitForShutdown();
    ros::spin();
  return 0;
}

