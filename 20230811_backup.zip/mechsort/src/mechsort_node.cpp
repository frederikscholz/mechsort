#include <ros/ros.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <geometry_msgs/Point.h>
#include <geometry_msgs/Pose.h>
#include <std_msgs/Bool.h>
#include <mechsort/YesNo.h> // Include the correct header file

class MechSort
{
public:
    MechSort();

private:
    ros::NodeHandle nh_;
    ros::Subscriber voxel_subscriber_;
    moveit::planning_interface::MoveGroupInterface move_group_;
    ros::Publisher target_pose_publisher_;
    ros::Publisher yn_check_publisher_;
    ros::ServiceServer yn_service_;

    bool confirmed_;

    void voxelCallback(const geometry_msgs::Point::ConstPtr& voxel_msg);
    void ynCheckCallback(const std_msgs::Bool::ConstPtr& yn_msg);
    bool yesNoServiceCallback(mechsort::YesNo::Request& request, mechsort::YesNo::Response& response);
    void executeMovement();
};

MechSort::MechSort() : nh_(), move_group_("sia10f_manipulator"), confirmed_(false)
{
    voxel_subscriber_ = nh_.subscribe("highest_voxel", 1, &MechSort::voxelCallback, this);

    move_group_.setEndEffectorLink("sia10f_tool0");

    target_pose_publisher_ = nh_.advertise<geometry_msgs::Pose>("mechsort_target_pose", 1);
    yn_check_publisher_ = nh_.advertise<std_msgs::Bool>("mechsort_yn_check", 1);

    yn_service_ = nh_.advertiseService("mechsort_yes_no_service", &MechSort::yesNoServiceCallback, this);
}

void MechSort::voxelCallback(const geometry_msgs::Point::ConstPtr& voxel_msg)
{
    ROS_INFO("Received voxel coordinates: x=%f, y=%f, z=%f", voxel_msg->x, voxel_msg->y, voxel_msg->z);

    // Set the target pose
    geometry_msgs::Pose target_pose;
    target_pose.position.x = voxel_msg->x;
    target_pose.position.y = voxel_msg->y;
    target_pose.position.z = voxel_msg->z;
    target_pose.orientation.w = 1.0;  // Assuming you want to keep the same orientation

    // Publish the target pose for visualization (optional)
    target_pose_publisher_.publish(target_pose);

    confirmed_ = false; // Reset the confirmation flag
    std_msgs::Bool confirm_msg;
    confirm_msg.data = true;
    yn_check_publisher_.publish(confirm_msg);
    ROS_INFO("Confirmation request published. Waiting for user response...");
}

void MechSort::ynCheckCallback(const std_msgs::Bool::ConstPtr& yn_msg)
{
    if (yn_msg->data)
    {
        if (!confirmed_)
        {
            ROS_INFO("Waiting for user confirmation (Y/N)...");
            char yn;
            std::cin >> yn;
            confirmed_ = (yn == 'Y' || yn == 'y');

            std_msgs::Bool confirm_msg;
            confirm_msg.data = confirmed_;
            yn_check_publisher_.publish(confirm_msg);
        }

        if (confirmed_)
        {
            ROS_INFO("User confirmed the movement.");
            executeMovement(); // Execute the movement once confirmed
        }
        else
        {
            ROS_INFO("Movement canceled by the user.");
        }
    }
}

bool MechSort::yesNoServiceCallback(mechsort::YesNo::Request& request, mechsort::YesNo::Response& response)
{
    response.confirmed = request.yes;
    return true;
}

void MechSort::executeMovement()
{
    // Plan and execute the movement
    moveit::planning_interface::MoveGroupInterface::Plan plan;
    bool success = (move_group_.plan(plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
    if (success)
    {
        ROS_INFO("Movement plan generated successfully. Executing movement...");
        move_group_.execute(plan);
        ROS_INFO("Movement executed successfully.");
    }
    else
    {
        ROS_WARN("Failed to plan the movement.");
    }
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "mechsort_node");
    MechSort mechsort;
    ros::spin();
    return 0;
}
