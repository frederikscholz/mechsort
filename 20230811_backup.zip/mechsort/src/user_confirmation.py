#!/usr/bin/env python3

import rospy
from std_msgs.msg import Bool

def user_confirmation_callback(msg):
    if msg.data:
        yn = raw_input("Do you want to proceed with the movement? (Y/N): ")
        confirm_msg = Bool()
        confirm_msg.data = (yn == 'Y' or yn == 'y')
        confirm_pub.publish(confirm_msg)

if __name__ == "__main__":
    rospy.init_node("user_confirmation_node")
    confirm_pub = rospy.Publisher("mechsort_yes_no", Bool, queue_size=1)
    rospy.Subscriber("mechsort_yn_check", Bool, user_confirmation_callback)
    rospy.spin()
